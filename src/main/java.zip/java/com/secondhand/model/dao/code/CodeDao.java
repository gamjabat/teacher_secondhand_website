package com.secondhand.model.dao.code;

import org.apache.ibatis.session.SqlSession;

import com.secondhand.model.dto.code.Code;

public class CodeDao {
//	 public Code getCodeByQnaNo(SqlSession session, String qnaNo) {
//	        return session.selectOne("code.getCodeByQnaNo", qnaNo);  // Mapper XML에서 SQL 실행
//	 }
}
